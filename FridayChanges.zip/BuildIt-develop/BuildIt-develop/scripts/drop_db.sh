#!/bin/bash
mysql -u root -p -e "DROP DATABASE buildit;"
