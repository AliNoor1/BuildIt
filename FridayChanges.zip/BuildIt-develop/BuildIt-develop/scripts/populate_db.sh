#!/bin/bash

mysql -u root -p -e "source populate_db.sql"