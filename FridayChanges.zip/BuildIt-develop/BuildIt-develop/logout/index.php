<?php include $_SERVER['DOCUMENT_ROOT']."/scripts/base.php"; $_SESSION = array(); session_destroy(); ?>
<meta http-equiv="refresh" content="0;/">