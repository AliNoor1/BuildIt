<?php include $_SERVER['DOCUMENT_ROOT'] . "/scripts/base.php";?>

    <!DOCTYPE html>
    <html>
    <head>
        <link href="BuildIT_Contractor_Page_style.css" type="text/css" rel="stylesheet">
        <link href="/css/navbar.css" type="text/css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>
    <title>Contracts</title>
    <body>

<?php include $_SERVER['DOCUMENT_ROOT'] . "/common/navbar.php";?>