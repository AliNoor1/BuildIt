<?php include $_SERVER['DOCUMENT_ROOT']."/common/footer.php";?>
</body>
</html>
